Clazz.declarePackage ("JZ");
Clazz.load (["java.io.IOException"], "JZ.ZStreamException", null, function () {
c$ = Clazz.declareType (JZ, "ZStreamException", java.io.IOException);
});
