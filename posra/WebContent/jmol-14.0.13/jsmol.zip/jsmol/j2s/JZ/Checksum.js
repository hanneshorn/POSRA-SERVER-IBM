Clazz.declarePackage ("JZ");
Clazz.declareInterface (JZ, "Checksum");
