Clazz.declarePackage ("JW");
Clazz.declareInterface (JW, "Triangulator");
