Clazz.declarePackage ("J.api");
Clazz.load (["J.api.JmolCallbackListener"], "J.api.JmolStatusListener", null, function () {
Clazz.declareInterface (J.api, "JmolStatusListener", J.api.JmolCallbackListener);
});
