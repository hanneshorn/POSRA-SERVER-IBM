Clazz.declarePackage ("JSV.common");
c$ = Clazz.declareType (JSV.common, "ZoomEvent");
Clazz.makeConstructor (c$, 
function () {
});
